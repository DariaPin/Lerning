package pages;

import org.openqa.selenium.WebElement;

import java.util.List;

public class LoginPage extends BasePage implements Page {
    @Override
    public void findElementAndClickFunction(String element) {

    }

    @Override
    public void findElementAndSendKeyFunction(String element, String text) {

    }

    @Override
    public void selectFromDropDown(String element) {

    }

    @Override
    public void hoverOverTheElement(String element) {

    }

    @Override
    public void initMap() {

    }

    @Override
    public void scrollToElement(String element) {

    }

    @Override
    public void randomClickOnElementInsideListOfWebElement(String ListOfWebElement) {

    }

    // Login page is an example of POM pages. Similar to that page will be created as we proceed in our project


}